To enable the height velocity diagram install copy the hv_diagram.ini into your aircraft folder
The plugin should recognize it upon the next restart restart
If you have no clue what this is about, read the manual or start getting into helicopters :-)
